# Contributor guidelines - CSSLint

* Check out the [Contributing wiki](https://github.com/stubbornella/csslint/wiki/Contributing) and [Developer Guidelines](https://github.com/stubbornella/csslint/wiki/Developer-Guide) first

* To add properties that CSSLint recognizes, submit a patch to [nzakas/parser-lib](https://github.com/nzakas/parser-lib)
